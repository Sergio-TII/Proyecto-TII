from django.urls import path, include

urlpatterns = [

    path("aplicacion/", include('myapp.urls')),
    #path('post/<int:pk>/', views.post_detail, name='post_detail'),
    #path('post/new/', views.post_new, name='post_new'),
]
