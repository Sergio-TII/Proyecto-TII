# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Asignatura(models.Model):
    codigo_asignatura = models.CharField(primary_key=True, max_length=15)
    nombre_asignatura = models.CharField(max_length=150)
    cantidad_alumno = models.IntegerField()
    nivel = models.CharField(max_length=4)

    class Meta:
        managed = True
        db_table = 'asignatura'


class Carrera(models.Model):
    unidad_academica = models.IntegerField(primary_key=True)
    nombre_carrera = models.CharField(max_length=150)
    carrera = models.CharField(max_length=16)

    class Meta:
        managed = True
        db_table = 'carrera'


class Cobertura(models.Model):
    id_cobertura = models.AutoField(primary_key=True)
    porcentaje_cobertura_b = models.IntegerField()
    tconsiderado_c = models.IntegerField()
    tconsiderado_b = models.IntegerField()
    tbibliografia_c = models.IntegerField()
    tbibliografia_b = models.IntegerField()
    porcentaje_cobertura_c = models.IntegerField()
    fecha_cobertura = models.DateField()
    rut = models.CharField(max_length=12)
    unidad_academica = models.ForeignKey(Carrera, models.DO_NOTHING, db_column='unidad_academica', unique=True)

    class Meta:
        managed = True
        db_table = 'cobertura'


class Libro(models.Model):
    id_libro = models.AutoField(primary_key=True)
    autor = models.CharField(max_length=100)
    titulo_libro = models.CharField(max_length=150)
    observacion = models.CharField(max_length=100)
    enlace_ebook = models.CharField(max_length=200)
    editorial = models.CharField(max_length=50)
    anio_libro = models.IntegerField()
    lugar = models.CharField(max_length=50)
    titulos_disponible = models.IntegerField()
    edicion = models.IntegerField()
    bibliografia = models.CharField(max_length=1)
    digital = models.CharField(max_length=11)

    class Meta:
        managed = True
        db_table = 'libro'


class Pertenece(models.Model):
    codigo_asignatura = models.ForeignKey(Asignatura, models.DO_NOTHING, db_column='codigo_asignatura', primary_key=True)
    plan_estudio = models.ForeignKey('PlanEstudio', models.DO_NOTHING, db_column='plan_estudio')

    class Meta:
        managed = True
        db_table = 'pertenece'
        unique_together = (('codigo_asignatura', 'plan_estudio'),)


class PlanEstudio(models.Model):
    plan_estudio = models.IntegerField(primary_key=True)

    class Meta:
        managed = True
        db_table = 'plan_estudio'


class Posee(models.Model):
    codigo_asignatura = models.ForeignKey(Asignatura, models.DO_NOTHING, db_column='codigo_asignatura', primary_key=True)
    unidad_academica = models.ForeignKey(Carrera, models.DO_NOTHING, db_column='unidad_academica')

    class Meta:
        managed = True
        db_table = 'posee'
        unique_together = (('codigo_asignatura', 'unidad_academica'),)


class Requiere(models.Model):
    codigo_asignatura = models.ForeignKey(Asignatura, models.DO_NOTHING, db_column='codigo_asignatura', primary_key=True)
    id_libro = models.ForeignKey(Libro, models.DO_NOTHING, db_column='id_libro')

    class Meta:
        managed = True
        db_table = 'requiere'
        unique_together = (('codigo_asignatura', 'id_libro'),)


class SeImparte(models.Model):
    nombre_sede = models.ForeignKey('Sede', models.DO_NOTHING, db_column='nombre_sede', primary_key=True)
    unidad_academica = models.ForeignKey(Carrera, models.DO_NOTHING, db_column='unidad_academica')

    class Meta:
        managed = True
        db_table = 'se_imparte'
        unique_together = (('nombre_sede', 'unidad_academica'),)


class Sede(models.Model):
    nombre_sede = models.CharField(primary_key=True, max_length=18)

    class Meta:
        managed = True
        db_table = 'sede'
