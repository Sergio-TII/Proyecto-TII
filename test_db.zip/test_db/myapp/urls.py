from django.urls import path
from . import views

urlpatterns = [
    #path('', views.post_list, name='post_list'),
    #path('post/<int:pk>/', views.post_detail, name='post_detail'),
    path('',views.index, name="index"),
    path('ingresar/', views.post_new_libro, name='post_new_libro'),
    path('people/', views.people, name='people')
]
