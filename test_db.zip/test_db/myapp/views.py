from django.http import HttpResponse
from django.shortcuts import render
from .forms import PostForm

from django_tables2 import RequestConfig
from .models import Libro
from .tables import LibroTable

def post_new_libro(request):
    form = PostForm()
    return render(request, 'myapp/index.html', {'form': form})


def people(request):
    table = LibroTable(Libro.objects.all())
    RequestConfig(request).configure(table)
    return render(request, 'myapp/people.html', {'table': table})


def index(request):
    return HttpResponse("hola")
