from django import forms
import django_tables2 as tables
from .models import Libro

class PostForm(forms.ModelForm):

    class Meta:
        model = Libro
        fields = "__all__"
        template_name = 'django_tables2/bootstrap.html'
